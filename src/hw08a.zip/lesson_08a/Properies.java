package lesson_08a;

public interface Properies {
    boolean running(int length);
    boolean jumping(int height);

    boolean isStatus();
    void setStatus(boolean status);
}
