package lesson_11;

public class Fruit {
    double weight;

}
