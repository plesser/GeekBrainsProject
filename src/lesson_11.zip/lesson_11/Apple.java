package lesson_11;

public class Apple extends Fruit{

    public Apple() {
        this.weight = 1;
    }
}
