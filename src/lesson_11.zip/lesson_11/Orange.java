package lesson_11;

public class Orange extends Fruit{
    public Orange() {
        this.weight = 1.5;
    }
}
