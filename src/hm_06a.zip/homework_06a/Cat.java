package homework_06a;

public class Cat extends Animal{
    public Cat(String name, int running, int swiming) {
        super(name, running, swiming);
    }
}
