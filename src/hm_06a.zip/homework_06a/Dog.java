package homework_06a;

public class Dog extends Animal{
    public Dog(String name, int running, int swiming) {
        super(name, running, swiming);
    }

}
