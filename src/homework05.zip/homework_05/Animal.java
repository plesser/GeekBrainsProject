package homework_05;

public abstract class Animal {

    public Animal() {
    }

    abstract public boolean run(float val);

    abstract public boolean sail(float val);

    abstract public boolean jump(float val);

}
